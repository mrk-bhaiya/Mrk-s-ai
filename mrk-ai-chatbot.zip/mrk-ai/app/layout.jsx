import './globals.css';
export const metadata = { title: 'MRK AI', description: 'Your AI chat assistant' };
export default function RootLayout({ children }) { return <html lang="en"><body>{children}</body></html>; }
