import OpenAI from 'openai';

export async function POST(req) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return Response.json({ error: 'Server setup needed: add your OPENAI_API_KEY in environment variables.' }, { status: 503 });
    }
    const body = await req.json();
    const messages = Array.isArray(body?.messages) ? body.messages : [];
    const clean = messages.filter(m => ['user', 'assistant'].includes(m?.role) && typeof m?.content === 'string' && m.content.trim()).slice(-20);
    if (!clean.length || clean.at(-1).role !== 'user') return Response.json({ error: 'Send a message to start.' }, { status: 400 });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-6-luna',
      instructions: 'You are MRK AI, a helpful, friendly, clear AI assistant. Be accurate, explain things simply when appropriate, and keep answers well organized. Do not claim to be ChatGPT.',
      input: clean.map(m => ({ role: m.role, content: m.content }))
    });
    return Response.json({ reply: response.output_text || 'I could not generate a reply. Please try again.' });
  } catch (err) {
    console.error('MRK AI route error:', err?.message);
    return Response.json({ error: 'The AI server could not respond. Please check your API setup and try again.' }, { status: 500 });
  }
}
