'use client';
import { useEffect, useRef, useState } from 'react';

const starter = [{ id: 'welcome', title: 'New chat', messages: [] }];
function id() { return Math.random().toString(36).slice(2, 10); }
export default function Home() {
  const [chats, setChats] = useState(starter);
  const [active, setActive] = useState('welcome');
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [sidebar, setSidebar] = useState(false);
  const endRef = useRef(null);
  const current = chats.find(c => c.id === active) || chats[0];
  useEffect(() => { try { const saved = JSON.parse(localStorage.getItem('mrk-ai-chats') || 'null'); if (saved?.length) { setChats(saved); setActive(saved[0].id); } } catch {} }, []);
  useEffect(() => { try { localStorage.setItem('mrk-ai-chats', JSON.stringify(chats)); } catch {} }, [chats]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [current?.messages?.length, busy]);
  function newChat() { const c = { id: id(), title: 'New chat', messages: [] }; setChats(prev => [c, ...prev]); setActive(c.id); setText(''); setSidebar(false); }
  function switchChat(cid) { setActive(cid); setSidebar(false); }
  function deleteChat(cid) { setChats(prev => { const next = prev.filter(c => c.id !== cid); if (!next.length) { const fresh = starter[0]; setActive(fresh.id); return [fresh]; } if (active === cid) setActive(next[0].id); return next; }); }
  async function send() {
    const content = text.trim(); if (!content || busy) return;
    const userMsg = { role: 'user', content };
    const updated = current.messages.concat(userMsg);
    setChats(prev => prev.map(c => c.id === active ? { ...c, title: c.messages.length ? c.title : content.slice(0, 36), messages: updated } : c));
    setText(''); setBusy(true);
    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: updated }) });
      const data = await res.json(); if (!res.ok) throw new Error(data.error || 'Request failed');
      setChats(prev => prev.map(c => c.id === active ? { ...c, messages: c.messages.concat({ role: 'assistant', content: data.reply }) } : c));
    } catch (e) {
      setChats(prev => prev.map(c => c.id === active ? { ...c, messages: c.messages.concat({ role: 'assistant', content: `⚠️ ${e.message}` }) } : c));
    } finally { setBusy(false); }
  }
  return <main className="appShell">
    <aside className={`sidebar ${sidebar ? 'open' : ''}`}>
      <div className="sideTop"><div className="brandMark">M</div><span>MRK AI</span><button className="iconBtn closeSide" onClick={() => setSidebar(false)} aria-label="Close menu">×</button></div>
      <button className="newChat" onClick={newChat}><span className="plus">＋</span> New chat</button>
      <div className="historyLabel">YOUR CHATS</div>
      <div className="chatList">{chats.map(c => <div key={c.id} className={`chatRow ${active === c.id ? 'selected' : ''}`}><button onClick={() => switchChat(c.id)} className="chatName">{c.title}</button><button className="deleteChat" title="Delete chat" onClick={() => deleteChat(c.id)}>⋯</button></div>)}</div>
      <div className="sideFooter"><span className="tinyLogo">M</span><div><b>MRK AI</b><small>AI chat assistant</small></div></div>
    </aside>
    {sidebar && <div className="scrim" onClick={() => setSidebar(false)} />}
    <section className="mainPanel">
      <header className="topbar"><button className="iconBtn menuBtn" onClick={() => setSidebar(true)} aria-label="Open sidebar">☰</button><div className="topBrand"><span className="brandMark small">M</span><strong>MRK AI</strong><span className="modelPill">AI assistant</span></div><button className="iconBtn newTop" onClick={newChat} title="New chat">＋</button></header>
      <div className="conversation">
        {current.messages.length === 0 ? <div className="welcome"><div className="welcomeIcon">✦</div><h1>What can I help you with?</h1><p>Ask anything. Let’s figure it out together.</p><div className="suggestions"><button onClick={() => setText('Explain a topic in simple words')}>✧ Explain something</button><button onClick={() => setText('Give me creative ideas for a project')}>✧ Brainstorm ideas</button><button onClick={() => setText('Help me plan my day')}>✧ Make a plan</button></div></div> : <div className="messages">{current.messages.map((m, i) => <div key={i} className={`message ${m.role}`}><div className="avatar">{m.role === 'assistant' ? '✦' : 'You'}</div><div className="messageText">{m.content}</div></div>)}{busy && <div className="message assistant"><div className="avatar">✦</div><div className="typing"><i></i><i></i><i></i></div></div>}<div ref={endRef} /></div>}
      </div>
      <div className="composerWrap"><form className="composer" onSubmit={e => { e.preventDefault(); send(); }}><button type="button" className="addBtn" title="New chat" onClick={newChat}>＋</button><textarea value={text} onChange={e => setText(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Message MRK AI…" rows={1} /><button type="submit" className="sendBtn" disabled={!text.trim() || busy} title="Send message">↑</button></form><div className="disclaimer">MRK AI can make mistakes. Check important information.</div></div>
    </section>
  </main>;
}
